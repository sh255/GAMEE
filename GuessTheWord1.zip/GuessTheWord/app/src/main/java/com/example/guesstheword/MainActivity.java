package com.example.guesstheword;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {
    public ProgressBar p;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        p = findViewById(R.id.progressBar_cyclic);
    }

    public void gotoHelpingVerb(View view) {
        
        Intent intent = new Intent(getApplicationContext() , HelpingVerb.class);
        startActivity(intent);

    }
}