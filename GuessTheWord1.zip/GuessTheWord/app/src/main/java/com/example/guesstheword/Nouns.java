package com.example.guesstheword;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.IOException;
import java.util.Random;
import java.util.concurrent.CountDownLatch;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Nouns extends AppCompatActivity {
    //public static final String questions[]={"Quidditch is the most popular sport among witches and wizards in “Harry Potter”","The Beatles is a famous rock band from Manchester, the United Kingdom.","Machu Picchu is an abandoned Incan citadel located in Chile","The star is the most common symbol used in all national flags around the world.","Black is the most commonly used colour in all national flags around the world.","A centaur, a mythical creature in many fictional works, is a combination of humans and dragons.","The capital of Australia is Sydney.","The World War II began in 1939 when Germany invaded Poland."," The FIFA World Cup 2022 will take place in Iran.","In 2019, the Nobel Prize in Mathematics was awarded to two Japanese scientists."};
    //public static final String answers[]={"yes","no","no","yes","no","no","no","yes","no","no"};
    public static int answer;
    public static int lives ;
    public static int scores ;
    public static TextView wordTextView;
    public static TextView livesTextView;
    public static TextView scoresTextView;
    public static String[] questions;
    public static String[] answers;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nouns);
        try {
            getData();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        wordTextView = findViewById(R.id.isWord);
        livesTextView = findViewById(R.id.lives);
        scoresTextView = findViewById(R.id.scores);
        lives = 3;
        scores = 0;
        answer = new Random().nextInt(questions.length);
        String randomStr = questions[answer];
        wordTextView.setText(randomStr);
    }
    public void yes(View view) {
        if(answers[answer].equals("yes")){
            Toast.makeText(getApplicationContext() , "Answer is correct   "+answers[answer]+" ",Toast.LENGTH_SHORT).show();
            answer = new Random().nextInt(questions.length);
            String randomStr = questions[answer];
            wordTextView.setText(randomStr);
            scores +=1;
            scoresTextView.setText(String.valueOf(scores));
            if(scores >= 3){
                createSuccessDialog();
            }
        }
        else{
            Toast.makeText(getApplicationContext() , "oops! Your Answer is incorrect ",Toast.LENGTH_SHORT).show();
            answer = new Random().nextInt(questions.length);
            String randomStr = questions[answer];
            wordTextView.setText(randomStr);
            lives -=1;
            livesTextView.setText(String.valueOf(lives));
            if(lives < 1){
                createGameOverDialog();
            }
        }
    }

    public void no(View view) {
        if(answers[answer].equals("no")){
            Toast.makeText(getApplicationContext() , "Answer is correct   "+answers[answer]+" ",Toast.LENGTH_SHORT).show();
            answer = new Random().nextInt(questions.length);
            String randomStr = questions[answer];
            wordTextView.setText(randomStr);
            scores +=1;
            scoresTextView.setText(String.valueOf(scores));
            if(scores >= 3){
                createSuccessDialog();
            }
        }
        else{
            Toast.makeText(getApplicationContext() , "oops! Your Answer is incorrect ",Toast.LENGTH_SHORT).show();
            answer = new Random().nextInt(questions.length);
            String randomStr = questions[answer];
            wordTextView.setText(randomStr);
            lives -=1;
            livesTextView.setText(String.valueOf(lives));
            if(lives < 1){
                createGameOverDialog();
            }
        }
    }

    public void createSuccessDialog(){
        AlertDialog.Builder alertDialog2 = new AlertDialog.Builder(
                Nouns.this);

// Setting Dialog Title
        alertDialog2.setTitle("WoW...!");

// Setting Dialog Message
        alertDialog2.setMessage("Congratulation You completed the Game");

// Setting Icon to Dialog
        //alertDialog2.setIcon(R.drawable.delete);

// Setting Positive "Yes" Btn
        alertDialog2.setPositiveButton("Home",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Write your code here to execute after dialog
//                        Toast.makeText(getApplicationContext(),
//                                "You clicked on YES", Toast.LENGTH_SHORT)
//                                .show();
                        Intent intent = new Intent(getApplicationContext() , MainActivity.class);
                        startActivity(intent);
                    }
                });
// Setting Negative "NO" Btn
//        alertDialog2.setNegativeButton("NO",
//                new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // Write your code here to execute after dialog
////                        Toast.makeText(getApplicationContext(),
////                                "You clicked on NO", Toast.LENGTH_SHORT)
////                                .show();
//                        dialog.cancel();
//                        Intent intent = new Intent(getApplicationContext() , MainActivity.class);
//                        startActivity(intent);
//                    }
//                });

// Showing Alert Dialog
        alertDialog2.show();
    }

    public void createGameOverDialog(){
        AlertDialog.Builder alertDialog1 = new AlertDialog.Builder(
                Nouns.this);

        // Setting Dialog Title
        alertDialog1.setTitle("Oops...!");

        // Setting Dialog Message
        alertDialog1.setMessage("You Failed and now you are out of Lives Try Again");

        // Setting Icon to Dialog
        //alertDialog1.setIcon(R.drawable.tick);

        // Setting OK Button
        alertDialog1.setPositiveButton("Back", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                // Write your code here to execute after dialog
                // closed
//                Toast.makeText(getApplicationContext(),
//                        "You clicked on OK", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext() , MainActivity.class);
                startActivity(intent);
            }
        });

        // Showing Alert Message
        alertDialog1.show();
    }

    public void getData() throws InterruptedException {

        OkHttpClient client = new OkHttpClient();
        String url = "https://ktechsryk.000webhostapp.com/api/api_2.php";

        Request request = new Request.Builder()
                .url(url)
                .build();
        JSONParser jsonParser = new JSONParser();
        CountDownLatch count = new CountDownLatch(1);
        client.newCall(request).enqueue(new Callback() {

            @Override
            public void onFailure(Call call, IOException e) {
                //Toast.makeText(HelpingVerb.this, "Something went wrong with request", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
                count.countDown();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    final String myResponse = response.body().string();

                    try {
                        JSONObject obj = new JSONObject(myResponse);//jsonParser.parse(myResponse);

                        JSONArray dataArrayq = obj.getJSONArray("questions");
                        JSONArray dataArraya = obj.getJSONArray("answers");
                        questions = new String[dataArrayq.length()];
                        answers = new String[dataArrayq.length()];
                        for(int i = 0 ; i < dataArrayq.length() ; i++){
                            questions[i] = dataArrayq.getString(i);
                            answers[i] = dataArraya.getString(i);
                        }
                        count.countDown();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
//                    can call here
//                    new DownLoadImageTask(image).execute(obj.toString());
                }
            }
        });
        count.await();

    }
}